# -*- coding: utf-8 -*-

VERSION = "2020.1"

OLSON_VERSION = "2020a"
